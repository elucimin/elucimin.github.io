clear all;
g = 0.02; alpha = 0.36;
b=0.7; delta = 0.08;
d=0.981; de = b*d/(1-d+b*d);
% IES = theta;
theta= 0.6:0.01:1.4;
R= (exp(g./theta) - (1 - b)*d*exp(g))/(b*d);
S =  alpha*(exp(g) - (1 - delta))./(R - (1 - delta));

Re= (exp(g./theta))/(de);
Se =  alpha*(exp(g) - (1 - delta))./(Re - (1 - delta));
subplot(1,2,1);
plot(theta,S,'-b','LineWidth',2); hold on;
plot(theta,Se,'--r','LineWidth',2)
ylabel('Savings rate'); xlabel('IES');
title('Positive growth rate (g=2%)')
legend('Quasi-Hyperbolic','Exponential')


g = -0.02; alpha = 0.36;
b=0.7; delta = 0.08;
d=0.981; de = b*d/(1-d+b*d);
% IES = theta;
R= (exp(g./theta) - (1 - b)*d*exp(g))/(b*d);
S =  alpha*(exp(g) - (1 - delta))./(R - (1 - delta));

Re= (exp(g./theta))/(de);
Se =  alpha*(exp(g) - (1 - delta))./(Re - (1 - delta));
subplot(1,2,2);
plot(theta,S,'-b','LineWidth',2); hold on;
plot(theta,Se,'--r','LineWidth',2)
ylabel('Savings rate'); xlabel('IES')
title('Negative growth rate (g=-2%)')
legend('Quasi-Hyperbolic','Exponential')
