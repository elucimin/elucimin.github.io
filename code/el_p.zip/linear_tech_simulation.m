clear all;
period=100;
R=rand(period,1)+0.7;
b=0.6;d=0.981;
W=100;
rho=1/1.1; RHO2=2;
X=mean ( R.^(1-rho));

myfun = @(LA,B,D) 1-(1-B)*LA - (1-LA)^rho/ (D * X);  % The parameterized function.
B=b;D=d;
laQ = fzero(@(x) myfun(x,B,D), 0.1)

B=1;D=b*d/(1-d+b*d);
laE = fzero(@(x) myfun(x,B,D), 0.1)

WQ(1)=W(1);WE(1)=W(1);
for i=1:period-1;
    IN(i)=i;
    SQ(i)=WQ(i)*(1-laQ);
    WQ(i+1)=SQ(i)*R(i+1);
    
    SE(i)=WE(i)*(1-laE);
    WE(i+1)=SE(i)*R(i+1);
end
IN(i+1)=i+1;
SQ(i+1)=nan;SE(i+1)=nan;


subplot(2,1,1);
plot(IN,log(WQ),'-b','LineWidth',1); hold on;
plot(IN,log(WE),'--r','LineWidth',1)
xlabel('Time'); ylabel('Log(Capital)')
title('Case: IES>1 (IES=1.1)')
legend('Quasi-Hyperbolic','Exponential')


rho=RHO2;
X=mean ( R.^(1-rho));

myfun = @(LA,B,D) 1-(1-B)*LA - (1-LA)^rho/ (D * X);  % The parameterized function.
B=b;D=d;
laQ = fzero(@(x) myfun(x,B,D), 0.1)

B=1;D=b*d/(1-d+b*d);
laE = fzero(@(x) myfun(x,B,D), 0.1)

WQ(1)=W(1);WE(1)=W(1);
for i=1:period-1;
    IN(i)=i;
    SQ(i)=WQ(i)*(1-laQ);
    WQ(i+1)=SQ(i)*R(i+1);
    
    SE(i)=WE(i)*(1-laE);
    WE(i+1)=SE(i)*R(i+1);
end
IN(i+1)=i+1;
SQ(i+1)=nan;SE(i+1)=nan;

%plot(IN,log(SQ),IN,log(SE))
%figure
subplot(2,1,2);
plot(IN,log(WQ),'-b','LineWidth',1); hold on;
plot(IN,log(WE),'--r','LineWidth',1)
xlabel('Time'); ylabel('Log(Capital)')
title('Case: IES<1 (IES=0.5)')
legend('Quasi-Hyperbolic','Exponential')


