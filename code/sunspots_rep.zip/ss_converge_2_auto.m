clear all;
d=0.08; g=0.02; b=0.980963; a=0.36; z=1;
theta=4; sig=0.03;
DF = @(k) (z*a*k^(a-1))
ta=sig;tb=-sig;
DPK = @(k,r) (DF(k)-(r+d));
r=exp(g)/b-1;
xa=(1+r)/r*(1/(1+ta)/(0.5*(1/(1+ta))+0.5*(1/(1+tb)))-1);
xb=(1+r)/r*(1/(1+tb)/(0.5*(1/(1+ta))+0.5*(1/(1+tb)))-1);
kor=((r+r*xa+d+(r+r*xb+d)*theta)/(a+a*theta))^(-1);


A(1)=1;
%capital-to-output
K(1)=kor^(1/(1-a));
Y(1)=A(1)*K(1)^a;
%C0+K1=Y0+(1-d)K0
C0=Y(1)/exp(g)+(1-d)*K(1)/exp(g)-K(1);

  h1=0.60;
  h2=0.75;
  hh=(h1+h2)/2;
  
  C(1)=Y(1)*hh;
  G(1)=1;  
 
  %capital-to-output steady state
  kor_S=((exp(g)/b-(1-d))/a)^(-1);
 
  
  CTOp(1)=kor;
  N=110;
  NN=N;
  t=0;
  
  while t<NN;
      t=t+1;
      A(t+1)=exp(g*(1-a))^(t);
      K(t+1)=Y(t)+(1-d)*K(t)-C(t);
      Y(t+1)=A(t+1)*K(t+1)^a;
    
      R(t+1)=(1-d)+a*Y(t+1)/K(t+1);
      C(t+1)=C(t)*R(t+1)*b;
      CTO(t)=K(t+1)/Y(t+1);
 %     G(t+1)=G(t)*exp(g);
 %     D(t)=0;
      CTOp(t+1)=CTO(t); 
      
      if CTO(t)>kor_S;
          h1=(h1+h2)/2;
          hh=(h1+h2)/2;
          t
          444
          t=0;
          C(1)=Y(1)*hh;
      elseif CTOp(t+1)<CTOp(t);
          h2=(h1+h2)/2;
          hh=(h1+h2)/2;
          111
          t=0;
          C(1)=Y(1)*hh;
      end
  
  end
  T=0:N;
      
 YF=30;
 subplot(2,1,1); plot(T,CTOp,'ob'); hold on
     line([0 max(T)],[kor_S,kor_S]);
     line([0 max(T)],[kor,kor]) 
     
subplot(2,1,1);ylabel('Capital-to-Ouput (k/y)'); xlabel('Year')
axis([0 YF kor-0.03 3.03])



%lifetime utility with indexed bonds
   U(1)=log(C(1));
   for i=2:N;
       U(i)=U(i-1)+b^(i-1)*log(C(i));
   end
   
   UI=U(i)+b^(i)/(1-b)*(log(C(i))+g/(1-g))
   
%lifetime utility without indexed bonds 
   c(1)=C0*exp(g);
   u(1)=log(c(1));
   for i=2:N;
       c(i)=exp(g)*c(i-1);
       u(i)=u(i-1)+b^(i-1)*log(c(i));
   end
   c(i+1)=c(i)*exp(g);
   ui=u(i)+b^(i)/(1-b)*(log(c(i))+g/(1-g))
   
% welfare cost
(exp(UI-ui+log(c(1)))/c(1)-1)*100

 TC=1:N+1;
subplot(2,1,2); plot(TC,C,'b',TC,c,'--r','LineWidth',1.5); hold on
axis([0 YF min(min(c),min(C)) C(YF)])
legend('Consumption with stabilizing policy',...
    'Consumption with inflation volatility')
ylabel('Consumption'); xlabel('Year')