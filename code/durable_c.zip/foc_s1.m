function y=foc_s1(x,h,p,p1,p2,y1,y2,y3,epsilon,sigma,alpha,delta,q,beta)

%x=(p2*s2-y2)+0.01;
s1=x;
s2=fun_s2(s1,h,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);

tol=10^-3;
s2_rhs=fun_s2(s1+tol,h,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
s2_lhs=fun_s2(s1-tol,h,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);

dif_s21=(s2_rhs-s2_lhs)/(2*tol);

uc1_rhs=utility(y1-p1*s1-p*h+tol,h,epsilon,sigma,alpha);
uc1_lhs=utility(y1-p1*s1-p*h-tol,h,epsilon,sigma,alpha);

dif_uc1=(uc1_rhs-uc1_lhs)/(2*tol);

lhs=p1*dif_uc1;

uc2_rhs=utility(s1-p2*s2+y2+tol,h,epsilon,sigma,alpha);
uc2_lhs=utility(s1-p2*s2+y2-tol,h,epsilon,sigma,alpha);

dif_uc2=(uc2_rhs-uc2_lhs)/(2*tol);

v1_rhs=utility_old((1-q)*h+s2+y3+tol,epsilon,sigma,alpha);
v1_lhs=utility_old((1-q)*h+s2+y3-tol,epsilon,sigma,alpha);

dif_v1=(v1_rhs-v1_lhs)/(2*tol);

rhs=beta*delta*dif_uc2*(1-p2*dif_s21)+beta*delta^2*dif_s21*dif_v1;

y=rhs-lhs;