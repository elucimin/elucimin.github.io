function y=foc_h(x,s1,p,p1,p2,y1,y2,y3,epsilon,sigma,alpha,delta,q,beta)

%x=10^-2;
h=x;
s2=fun_s2(s1,h,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);

tol=10^-3;
s2_rhs=fun_s2(s1,h+tol,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
s2_lhs=fun_s2(s1,h-tol,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);

dif_s2h=(s2_rhs-s2_lhs)/(2*tol);

uc1_rhs=utility(y1-p1*s1-p*h+tol,h,epsilon,sigma,alpha);
uc1_lhs=utility(y1-p1*s1-p*h-tol,h,epsilon,sigma,alpha);

dif_uc1=(uc1_rhs-uc1_lhs)/(2*tol);

uc2_rhs=utility(s1-p2*s2+y2+tol,h,epsilon,sigma,alpha);
uc2_lhs=utility(s1-p2*s2+y2-tol,h,epsilon,sigma,alpha);

dif_uc2=(uc2_rhs-uc2_lhs)/(2*tol);

%h=0.001;
uh1_rhs=utility(y1-p1*s1-p*h,h+tol,epsilon,sigma,alpha);
uh1_lhs=utility(y1-p1*s1-p*h,h-tol,epsilon,sigma,alpha);

dif_u1h=(uh1_rhs-uh1_lhs)/(2*tol);

uh2_rhs=utility(s1-p2*s2+y2,h+tol,epsilon,sigma,alpha);
uh2_lhs=utility(s1-p2*s2+y2,h-tol,epsilon,sigma,alpha);

dif_u2h=(uh2_rhs-uh2_lhs)/(2*tol);

v1_rhs=utility_old((1-q)*h+s2+y3+tol,epsilon,sigma,alpha);
v1_lhs=utility_old((1-q)*h+s2+y3-tol,epsilon,sigma,alpha);

dif_v1=(v1_rhs-v1_lhs)/(2*tol);

lhs=p*dif_uc1;

rhs=dif_u1h+beta*delta*dif_u2h+beta*delta*dif_uc2*(-p2*dif_s2h)...
    +beta*delta^2*dif_v1*((1-q)+dif_s2h);

y=rhs-lhs;





