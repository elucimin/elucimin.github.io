function y=foc2(x,s1,h,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta)

%x=(s1+y2)/p2*0.99;
%x=(-y3-(1-q)*h)*0.9;
%h=10^-3;
%h=0.01;

 %h=10^-2;
 %s1=5;
 %x=(-y3-(1-q)*h)+10^-3;
s2=x;

tol=10^-3;


u1_rhs=utility(s1-p2*s2+y2+tol,h,epsilon,sigma,alpha);
u1_lhs=utility(s1-p2*s2+y2-tol,h,epsilon,sigma,alpha);

dif_u1=(u1_rhs-u1_lhs)/(2*tol);

lhs=p2*dif_u1;


v1_rhs=utility_old((1-q)*h+s2+y3+tol,epsilon,sigma,alpha);
v1_lhs=utility_old((1-q)*h+s2+y3-tol,epsilon,sigma,alpha);

dif_v1=(v1_rhs-v1_lhs)/(2*tol);


rhs=beta*delta*dif_v1;

y=rhs-lhs;




