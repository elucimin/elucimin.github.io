function y=utility(c,h,epsilon,sigma,alpha)
%c=1.5;
%h=0;

%c=13.5
if epsilon~=1

  power=(epsilon-1)/epsilon;

  f=(alpha*c^(power)+(1-alpha)*h^(power))^(1/power);
else
    
    f=c^alpha*h^(1-alpha);
end

if sigma~=1
    y=f^(1-1/sigma);
    y=y/(1-1/sigma);
else
    y=log(f);
end
  