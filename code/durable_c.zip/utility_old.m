function y=utility_old(c,epsilon,sigma,alpha)
%c=1.5;
%h=0;
% if epsilon~=1
% 
%   power=(epsilon-1)/epsilon;
% 
%   f=(alpha*c^(power)+(1-alpha)*h^(power))^(1/power);
% else
%     
%     f=c^alpha*h^(1-alpha);
% end

if sigma~=1
    y=c^(1-1/sigma);
    y=y/(1-1/sigma);
else
    y=log(c);
end
  