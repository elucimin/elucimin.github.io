%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This programe is written for hyperbolic housing demand 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; close all; clc; 
y1=100;
y2=0;
y3=0;

p1=0.5;  %% implying R2=2
p2=0.5;  %% implying R3=2

q=0.75;
delta=0.5;
alpha=0.7;
sigma=0.43;
epsilon=1.2;
beta=0.3;

s1=5;

h=10;
p=0.4;

s1_new=s1;

h_new=h;
   
dist=1;

tol=10^-4;
int=1;
step=0.5;
max_iter=10000;



grid=10;
housing=zeros(grid,1);
premium=zeros(grid,1);
pp=linspace(3,8,grid);
pp=pp';
for i=1:grid
h=10;
p=pp(i);

s1_new=s1;
%s2_new=s2;
h_new=h;

dist=1;

tol=10^-4;
int=1;
step=0.5;
max_iter=10000;
while dist>tol & int<max_iter
    s1=(1-step)*s1+step*s1_new;
    %s2=(1-step)*s2+step*s2_new;
    h=(1-step)*h+step*h_new;
    
   %fun1=@(x)foc_s2(s1,x,h,p);
   %s2_new=fzero(fun1,[-(y3+(1-q)*h)*1.01,0.99*(s1+y2)/p2]);
   %s2_new=fzero(fun1,1);
   
   s2=fun_s2(s1,h,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);

   
   fun1=@(x)foc_s1(x,h,p,p1,p2,y1,y2,y3,epsilon,sigma,alpha,delta,q,beta);

   %s1_new=fzero(fun1,[(p2*s2-y2)*0.9,(y1-p*h)/p1*0.99]);
   s1_new=fzero(fun1,(y1-p*h)/p1*0.5);
   %s1_new=fzero(fun2,1);

   fun2=@(x)foc_h(x,s1,p,p1,p2,y1,y2,y3,epsilon,sigma,alpha,delta,q,beta);
   h_new=fzero(fun2,[10^-1,(y1-p1*s1)*0.9/p]);
   %fplot(fun2,[10^-2,(y1-p1*s1)*0.5/p])
   %h_new=fzero(fun3,2);
   
   dist=[abs((s1_new-s1)/s1);abs((h_new-h)/h)];
   dist=max(dist);
   
   int=int+1;
   disp(['-int' num2str(int) '-dist' num2str(dist)]);
  % disp(['-s1-' num2str(s1_new) '-h-' num2str(h_new)]);
end

housing(i)=h_new;
s2_rhs=fun_s2(s1_new+10^-3,h_new,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
s2_lhs=fun_s2(s1_new-10^-3,h_new,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);

dif_s21=(s2_rhs-s2_lhs)/(2*10^-3);

s2_rhs=fun_s2(s1_new,h_new+10^-3,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
s2_lhs=fun_s2(s1_new,h_new-10^-3,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);

dif_s2h=(s2_rhs-s2_lhs)/(2*10^-3);

premium(i)=dif_s2h-(1-q)*(p2*dif_s21-1);

end

output_path = '../paper/tabfig/';

 figure;
 plot(pp,housing,'LineWidth',3); hold on;
 plot(pp,housing-premium,'LineWidth',3)
 %axis([20 120 0 1]);
 line([5 5], get(gca, 'ylim'),'color','k',...
     'linestyle','--','linewidth',2);
 out_fname = ['demand' '.eps'];
  print('-depsc',[output_path out_fname]),xlabel('housing demand'),ylabel('housing price')
 
 
%  s2_rhs=fun_s2(s1_new+10^-3,h_new,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
% s2_lhs=fun_s2(s1_new-10^-3,h_new,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
% 
% dif_s21=(s2_rhs-s2_lhs)/(2*10^-3);
% 
% s2_rhs=fun_s2(s1_new,h_new+10^-3,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
% s2_lhs=fun_s2(s1_new,h_new-10^-3,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
% 
% dif_s2h=(s2_rhs-s2_lhs)/(2*10^-3);
% 
% premium=dif_s2h-(1-q)*(p2*dif_s21-1);
 
 
 
 
 
 
 
 
 %plot(pp,premium,'LineWidth',3)
 %out_fname = ['premium' '.eps'];
%  out_fname = ['premium2' '.eps'];
%  print('-depsc',[output_path out_fname]),xlabel('price'),ylabel('hyperbolic premium')
%  
%  
%  figure;
%  %out_fname = ['premiumratio' '.eps'];
%  out_fname = ['premiumratio2' '.eps'];
%  plot(pp,premium./pp,'LineWidth',3),xlabel('price'),ylabel('hyperbolic premium in price')
%  print('-depsc',[output_path out_fname]);





% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % the following is to set beta=1
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% beta=1;
% s1=5;
% %s2=5;
% 
% grid=10;
% housing_no=zeros(grid,1);
% pp=linspace(0.5,5,grid);
% for i=1:grid
% h=10;
% p=pp(i);
% 
% s1_new=s1;
% %s2_new=s2;
% h_new=h;
% 
% dist=1;
% 
% tol=10^-4;
% int=1;
% step=0.5;
% max_iter=10000;
% while dist>tol & int<max_iter
%     s1=(1-step)*s1+step*s1_new;
%     %s2=(1-step)*s2+step*s2_new;
%     h=(1-step)*h+step*h_new;
%     
%    %fun1=@(x)foc_s2(s1,x,h,p);
%    %s2_new=fzero(fun1,[-(y3+(1-q)*h)*1.01,0.99*(s1+y2)/p2]);
%    %s2_new=fzero(fun1,1);
%    
%    s2=fun_s2(s1,h,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
% 
%    
%    fun1=@(x)foc_s1(x,h,p,p1,p2,y1,y2,y3,epsilon,sigma,alpha,delta,q,beta);
% 
%    %s1_new=fzero(fun1,[(p2*s2-y2)*0.9,(y1-p*h)/p1*0.99]);
%    s1_new=fzero(fun1,(y1-p*h)/p1*0.5);
%    %s1_new=fzero(fun2,1);
% 
%    fun2=@(x)foc_h(x,s1,p,p1,p2,y1,y2,y3,epsilon,sigma,alpha,delta,q,beta);
%    h_new=fzero(fun2,[10^-1,(y1-p1*s1)*0.9/p]);
%    %fplot(fun2,[10^-2,(y1-p1*s1)*0.5/p])
%    %h_new=fzero(fun3,2);
%    
%    dist=[abs((s1_new-s1)/s1);abs((h_new-h)/h)];
%    dist=max(dist);
%    
%    int=int+1;
%    disp(['-int' num2str(int) '-dist' num2str(dist)]);
%   % disp(['-s1-' num2str(s1_new) '-h-' num2str(h_new)]);
% end
% housing_no(i)=h_new;
% end
% 
% figure;
% plot(pp,housing),hold on, plot(pp,housing_no,'--r'),legend('hyperbolic','no hyperbolic')
% figure;
% plot(pp,housing_no./housing)
% toc;  




