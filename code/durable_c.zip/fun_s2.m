function s2=fun_s2(s1,h,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta)

%h=0;
%h=10^-2;
%s1=5;

fun=@(x) foc2(x,s1,h,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
 %fplot(fun, [(-y3-(1-q)*h)*0.9,(s1+y2)/p2*0.99])   
 options = optimset('FunValCheck','off'); 
s2=fzero(fun,[(-y3-(1-q)*h)*0.9,(s1+y2)/p2*0.99],options);
%s2=fzero(fun,(s1+y2)/p2*0.5);

