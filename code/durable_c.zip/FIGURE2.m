clear all;
beta=1;delta=1;

p2=(1/(beta*delta))/2; 
p1=(1/(beta*delta^2))/2;
q=p1+p2;

T=700;

for i=1:T;
    k=1;
for j=1:T;
	Q1(i)=(i/T)*q;Q2(j)=(j/T)*q;
	q1=Q1(i); q2=Q2(j);
	mu=beta*delta^2;
	la=beta*delta;

	c2_h = @ (h) 1/( (la*p2)^(2/3) * h^(1/3) *2^(2/3));

	A= (1/2)*(2*(beta*delta^2)*p1)^(1/3);
	B=beta*delta*(2*la*p2)^(1/3)/3;
	C= beta*delta^2*p2*(2*la*p2)^(-2/3)/3;

	D=(A+B+C)/(mu*q);
	H=D^(3/4);
	C1= ((A*2)*H^(1/6))^(-2);
	C2= c2_h(H);
	C3=30-(p1*C1+q*H+p2*C2);
 

	c1=(q1/(4*mu^2*p1^3))^(1/4);
	h1=(p1/(4*mu^2*q1^3))^(1/4);
	c2=(q2/(4*la^2*p2^3))^(1/4);
	h2=(p2/(4*la^2*q2^3))^(1/4);
	c3=30-(p1*c1+q1*h1+p2*c2+q2*h2);

	U1= @(c1,h1,c2,h2,c3) -(c1*h1)^(-1/2)-beta*delta*(c2*h2)^(-1/2) +beta*delta^2*c3;
	OU=U1(C1,H,C2,H,C3);
	RU=U1(c1,h1,c2,h2,c3) ;
    
    
	if OU*k>RU; 
        X(i)=i/T*q; Y(i)=j/T*q;
        k=0; hold on;
    end
    
  
end

if k==1; X(i)=NaN; end


end

p1p=delta;p2p=2*beta*delta;
P=1+delta;
subplot(1,2,1);
line([0 P],[P,0]); hold on;
plot(P/2,P/2,'+');
plot(X*(p1p*p2p),Y*p2p)

%%%%%%%%%%%%%
beta=0.2; delta=1;

p2=(1/(beta*delta))/2; 
p1=(1/(beta*delta^2))/2;
q=p1+p2;

T=700;

for i=1:T;
    k=1;
for j=1:T;
	Q1(i)=(i/T)*q;Q2(j)=(j/T)*q;
	q1=Q1(i); q2=Q2(j);
	mu=beta*delta^2;
	la=beta*delta;

	c2_h = @ (h) 1/( (la*p2)^(2/3) * h^(1/3) *2^(2/3));

	A= (1/2)*(2*(beta*delta^2)*p1)^(1/3);
	B=beta*delta*(2*la*p2)^(1/3)/3;
	C= beta*delta^2*p2*(2*la*p2)^(-2/3)/3;

	D=(A+B+C)/(mu*q);
	H=D^(3/4);
	C1= ((A*2)*H^(1/6))^(-2);
	C2= c2_h(H);
	C3=30-(p1*C1+q*H+p2*C2);
 

	c1=(q1/(4*mu^2*p1^3))^(1/4);
	h1=(p1/(4*mu^2*q1^3))^(1/4);
	c2=(q2/(4*la^2*p2^3))^(1/4);
	h2=(p2/(4*la^2*q2^3))^(1/4);
	c3=30-(p1*c1+q1*h1+p2*c2+q2*h2);

	U1= @(c1,h1,c2,h2,c3) -(c1*h1)^(-1/2)-beta*delta*(c2*h2)^(-1/2) +beta*delta^2*c3;
	OU=U1(C1,H,C2,H,C3);
	RU=U1(c1,h1,c2,h2,c3) ;
    
    
	if OU*k>RU; 
        X(i)=i/T*q; Y(i)=j/T*q;
        k=0; hold on;
    end
    
  
end

if k==1; X(i)=NaN; end


end

p1p=delta;p2p=2*beta*delta;
P=1+delta;
subplot(1,2,2);
line([0 P],[P,0]); hold on;
plot(P/2,P/2,'+');
plot(X*(p1p*p2p),Y*p2p)

