%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This programe is written for hyperbolic housing demand with Minwook 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
clear all; close all; clc;

beta_vec=linspace(0.1,1,10);
premium=zeros(10,1);
inb=zeros(10,1);
for j=1:10
y1=100;
y2=0;
y3=0;

p1=0.5;
p2=0.5;

q=0.5;
delta=0.5;
alpha=0.686;
sigma=0.2;
epsilon=1;
beta=beta_vec(j);

s1=5;

  
dist=1;

tol=10^-4;
int=1;
step=0.5;
max_iter=10000;



grid=100;
housing=zeros(grid,1);

pp=linspace(3,8,grid);
pp=pp';
for i=1:grid
h=10;
p=pp(i);

s1_new=s1;
%s2_new=s2;
h_new=h;

dist=1;

tol=10^-4;
int=1;
step=0.5;
max_iter=10000;
while dist>tol & int<max_iter
    s1=(1-step)*s1+step*s1_new;
    %s2=(1-step)*s2+step*s2_new;
    h=(1-step)*h+step*h_new;
    
   %fun1=@(x)foc_s2(s1,x,h,p);
   %s2_new=fzero(fun1,[-(y3+(1-q)*h)*1.01,0.99*(s1+y2)/p2]);
   %s2_new=fzero(fun1,1);
   
   s2=fun_s2(s1,h,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);

   
   fun1=@(x)foc_s1(x,h,p,p1,p2,y1,y2,y3,epsilon,sigma,alpha,delta,q,beta);

   %s1_new=fzero(fun1,[(p2*s2-y2)*0.9,(y1-p*h)/p1*0.99]);
   s1_new=fzero(fun1,(y1-p*h)/p1*0.5);
   %s1_new=fzero(fun2,1);

   fun2=@(x)foc_h(x,s1,p,p1,p2,y1,y2,y3,epsilon,sigma,alpha,delta,q,beta);
   h_new=fzero(fun2,[10^-1,(y1-p1*s1)*0.9/p]);
   %fplot(fun2,[10^-2,(y1-p1*s1)*0.5/p])
   %h_new=fzero(fun3,2);
   
   dist=[abs((s1_new-s1)/s1);abs((h_new-h)/h)];
   dist=max(dist);
   
   int=int+1;
   disp(['-int' num2str(int) '-dist' num2str(dist)]);
  % disp(['-s1-' num2str(s1_new) '-h-' num2str(h_new)]);
end

housing(i)=h_new;


end
[ina,inb(j)]=min(abs(housing-5));
h_new=housing(inb(j));
s2_rhs=fun_s2(s1_new+10^-3,h_new,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
s2_lhs=fun_s2(s1_new-10^-3,h_new,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);

dif_s21=(s2_rhs-s2_lhs)/(2*10^-3);

s2_rhs=fun_s2(s1_new,h_new+10^-3,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
s2_lhs=fun_s2(s1_new,h_new-10^-3,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);

dif_s2h=(s2_rhs-s2_lhs)/(2*10^-3);

up=dif_s2h-(1-q)*(p2*dif_s21-1);
down=(1-q)*beta+(1-q)*p2*dif_s21*(1-beta);

premium(j,1)=up/down;
end

for j=1:10
    premium(j,1)=(1-beta)*premium(j,1)*p1*p2*(1-q);
end

toc;

share=zeros(10,1);
for i=1:10
    share(i)=premium(i,1)/pp(inb(i));
end
save('comparative.mat');

figure;
plot(beta_vec,share,'LineWidth',3)
 output_path = '../paper/tabfig/';
 out_fname = ['premium' '.eps'];
 print('-depsc',[output_path out_fname]),xlabel('beta'),ylabel('hyperbolic premium/housing price')

 
%  load('comparative.mat');
%  
%  for j=1:10
%     
%      h_new=housing(inb(j));
%      s2_rhs=fun_s2(s1_new+10^-3,h_new,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
%      s2_lhs=fun_s2(s1_new-10^-3,h_new,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
% 
%       dif_s21=(s2_rhs-s2_lhs)/(2*10^-3);
% 
%       s2_rhs=fun_s2(s1_new,h_new+10^-3,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
%       s2_lhs=fun_s2(s1_new,h_new-10^-3,p2,y2,y3,epsilon,sigma,alpha,delta,q,beta);
% 
%      dif_s2h=(s2_rhs-s2_lhs)/(2*10^-3);
% 
%      up=dif_s2h-(1-q)*(p2*dif_s21-1);
%        down=(1-q)*beta+(1-q)*p2*dif_s21*(1-beta);
% 
%      premium(j,1)=up/down;
%      premium(j,1)=(1-beta_vec(j))*premium(j,1)*p1*p2*(1-q);
%      share(j,1)=premium(j,1)/pp(inb(j));
%  end
%  
% 
% figure;
% plot(beta_vec,share,'LineWidth',3)
%  output_path = '../paper/tabfig/';
%  out_fname = ['premium' '.eps'];
%  print('-depsc',[output_path out_fname]),xlabel('beta'),ylabel('hyperbolic premium/housing price')


